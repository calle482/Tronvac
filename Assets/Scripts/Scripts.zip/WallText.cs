using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WallText : MonoBehaviour
{

    public static float shootsFired = 0;
    Text missed;


    // Start is called before the first frame update
    void Start()
    {
        missed = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        missed.text="Accuracy: " + Score.scoreValue / shootsFired * 100;
    }
}
