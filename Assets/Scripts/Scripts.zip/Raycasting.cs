using UnityEngine;

public class Raycasting : MonoBehaviour
{
    public float damage = 10f;
    public float range = 100f;
    public ParticleSystem muzzleFlash;

    public Camera fpsCam;

    public AudioSource source;
    public AudioClip clip;

    // Update is called once per frame
    void Update()
    {
        // Skjuter ut en raycast och spelar skjut ljudet när vänsta musknappen trycks ner
        if(Input.GetButtonDown("Fire1"))
        {
        RaycastHit hit;
        muzzleFlash.Play();
        WallText.shootsFired +=1;
        Debug.Log(WallText.shootsFired); 
        if (Physics.Raycast(fpsCam.transform.position, fpsCam.transform.forward, out hit, range))
            {
                Debug.Log(hit.transform.name);
                Target target = hit.transform.GetComponent<Target>();
                if (target != null)
                {
                    target.TakeDamage(damage);
                } 
            }
        if(Physics.Raycast(fpsCam.transform.position, fpsCam.transform.forward, out hit, range) && hit.transform.tag == "wall")
            {
                source.PlayOneShot(clip);
            }
        }

    }


}
